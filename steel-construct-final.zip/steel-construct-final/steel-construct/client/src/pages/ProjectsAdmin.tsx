import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Loader2, Upload, Trash2, Plus } from "lucide-react";

export default function ProjectsAdmin() {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "Aluminum",
    location: "",
    year: new Date().getFullYear().toString(),
    size: "medium" as "small" | "medium" | "large",
    imageFile: null as File | null,
  });

  const projectsQuery = trpc.projects.list.useQuery();
  const createMutation = trpc.projects.create.useMutation();
  const deleteMutation = trpc.projects.delete.useMutation();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData({ ...formData, imageFile: file });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.category || !formData.imageFile) {
      toast.error("Please fill in all required fields and select an image");
      return;
    }

    try {
      await createMutation.mutateAsync({
        title: formData.title,
        description: formData.description,
        category: formData.category,
        location: formData.location,
        year: formData.year,
        size: formData.size,
        imageFile: formData.imageFile,
      });

      toast.success("Project added successfully!");
      setFormData({
        title: "",
        description: "",
        category: "Aluminum",
        location: "",
        year: new Date().getFullYear().toString(),
        size: "medium",
        imageFile: null,
      });
      setIsAdding(false);
      projectsQuery.refetch();
    } catch (error) {
      toast.error("Failed to add project");
      console.error(error);
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this project?")) {
      try {
        await deleteMutation.mutateAsync({ id });
        toast.success("Project deleted successfully!");
        projectsQuery.refetch();
      } catch (error) {
        toast.error("Failed to delete project");
        console.error(error);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F7F4] p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-[#001F4D] mb-2">Projects Management</h1>
          <p className="text-[#666]">Upload and manage your Building Clouds project photos</p>
        </div>

        {!isAdding ? (
          <Button
            onClick={() => setIsAdding(true)}
            className="mb-8 bg-[#FF6B35] hover:bg-[#E55A24] text-white"
          >
            <Plus size={16} className="mr-2" />
            Add New Project
          </Button>
        ) : null}

        {isAdding && (
          <Card className="mb-8 border-[#FF6B35]">
            <CardHeader>
              <CardTitle>Add New Project</CardTitle>
              <CardDescription>Upload a photo and details for your project</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[#001F4D] mb-2">
                      Project Title *
                    </label>
                    <Input
                      required
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="e.g., Meridian Corporate Tower"
                      className="border-[#ddd]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#001F4D] mb-2">
                      Category *
                    </label>
                    <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                      <SelectTrigger className="border-[#ddd]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Aluminum">Aluminum Fabrication</SelectItem>
                        <SelectItem value="Steel">Steel Fabrication</SelectItem>
                        <SelectItem value="Construction">Construction</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#001F4D] mb-2">
                      Location
                    </label>
                    <Input
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      placeholder="e.g., Dubai, UAE"
                      className="border-[#ddd]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#001F4D] mb-2">
                      Year
                    </label>
                    <Input
                      value={formData.year}
                      onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                      placeholder="2024"
                      className="border-[#ddd]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#001F4D] mb-2">
                      Grid Size
                    </label>
                    <Select value={formData.size} onValueChange={(value: any) => setFormData({ ...formData, size: value })}>
                      <SelectTrigger className="border-[#ddd]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="small">Small</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="large">Large</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#001F4D] mb-2">
                      Project Image *
                    </label>
                    <Input
                      required
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="border-[#ddd]"
                    />
                    {formData.imageFile && (
                      <p className="text-sm text-[#666] mt-2">{formData.imageFile.name}</p>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#001F4D] mb-2">
                    Description
                  </label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe your project..."
                    className="border-[#ddd] min-h-24"
                  />
                </div>

                <div className="flex gap-3">
                  <Button
                    type="submit"
                    disabled={createMutation.isPending}
                    className="bg-[#FF6B35] hover:bg-[#E55A24] text-white"
                  >
                    {createMutation.isPending ? (
                      <>
                        <Loader2 size={16} className="mr-2 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload size={16} className="mr-2" />
                        Add Project
                      </>
                    )}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsAdding(false)}
                    className="border-[#ddd]"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        <div>
          <h2 className="text-2xl font-bold text-[#001F4D] mb-4">Your Projects</h2>
          {projectsQuery.isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 size={32} className="animate-spin text-[#FF6B35]" />
            </div>
          ) : projectsQuery.data && projectsQuery.data.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projectsQuery.data.map((project) => (
                <Card key={project.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="aspect-video overflow-hidden bg-[#eee]">
                    <img
                      src={project.imageUrl}
                      alt={project.title}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <CardContent className="pt-4">
                    <h3 className="font-bold text-[#001F4D] mb-1">{project.title}</h3>
                    <p className="text-sm text-[#666] mb-2">{project.category}</p>
                    {project.location && (
                      <p className="text-xs text-[#999] mb-1">{project.location}</p>
                    )}
                    {project.year && (
                      <p className="text-xs text-[#999] mb-3">{project.year}</p>
                    )}
                    {project.description && (
                      <p className="text-sm text-[#666] mb-4 line-clamp-2">{project.description}</p>
                    )}
                    <Button
                      onClick={() => handleDelete(project.id)}
                      disabled={deleteMutation.isPending}
                      variant="destructive"
                      size="sm"
                      className="w-full"
                    >
                      <Trash2 size={14} className="mr-2" />
                      Delete
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="text-center py-12">
              <p className="text-[#666] mb-4">No projects yet. Add your first project to get started!</p>
              <Button
                onClick={() => setIsAdding(true)}
                className="bg-[#FF6B35] hover:bg-[#E55A24] text-white"
              >
                <Plus size={16} className="mr-2" />
                Add Project
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
