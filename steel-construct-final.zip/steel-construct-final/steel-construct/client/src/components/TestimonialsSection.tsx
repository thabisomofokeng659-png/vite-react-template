/*
 * DESIGN: Precision Engineering Aesthetic
 * Testimonials: Warm off-white background, quote cards with left gold border
 * Playfair Display for quotes, Source Sans 3 for attribution
 */

import { useEffect, useRef, useState } from "react";
import { Quote } from "lucide-react";

const testimonials = [
  {
    quote:
      "Building Clouds delivered exceptional quality on our aluminum doors and windows project. Their attention to detail and professional installation was outstanding. Highly recommended!",
    name: "Rethabile",
    initials: "R",
  },
  {
    quote:
      "We worked with Building Clouds on our steel security gates and palisade fencing. Their team was professional, efficient, and delivered exactly what we needed on time and on budget.",
    name: "Mponeng",
    initials: "M",
  },
  {
    quote:
      "From consultation to completion, Building Clouds provided seamless service on our construction project. Their craftsmanship and professionalism exceeded our expectations.",
    name: "Maleshwane",
    initials: "M",
  },
];

export default function TestimonialsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold: 0.15 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section className="py-24 lg:py-32 bg-[#F5F5F5]">
      <div className="container" ref={ref}>
        {/* Section Header */}
        <div
          className={`mb-14 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-px bg-[#FF6B35]" />
            <span
              className="text-[#FF6B35] uppercase tracking-[0.25em] text-xs"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              Client Voices
            </span>
          </div>
          <h2
            className="text-[#001F4D] leading-tight max-w-lg"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
              fontWeight: 700,
            }}
          >
            What Our{" "}
            <span className="text-[#FF6B35] italic">Clients Say</span>
          </h2>
        </div>

        {/* Testimonial Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className={`bg-white border-l-4 border-[#FF6B35] p-8 shadow-sm hover:shadow-md transition-all duration-500 ${
                inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              {/* Quote icon */}
              <Quote size={28} className="text-[#FF6B35]/30 mb-5" />

              {/* Quote text */}
              <blockquote
                className="text-[#1C2B3A]/80 leading-relaxed mb-6 text-[0.93rem]"
                style={{ fontFamily: "'Source Sans 3', sans-serif" }}
              >
                "{t.quote}"
              </blockquote>

              {/* Attribution */}
              <div className="flex items-center gap-3 pt-4 border-t border-[#1C2B3A]/08">
                <div
                  className="w-10 h-10 bg-[#001F4D] flex items-center justify-center text-[#FF6B35] font-bold text-xs flex-shrink-0"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  {t.initials}
                </div>
                <div>
                  <div
                    className="text-[#1C2B3A] font-semibold text-sm"
                    style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                  >
                    {t.name}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
