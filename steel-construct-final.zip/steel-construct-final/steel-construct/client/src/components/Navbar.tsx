/*
 * DESIGN: Building Clouds Branding
 * Navbar: Navy blue (#001F4D) background, orange (#FF6B35) accents
 * Logo, navigation, CTA button
 */

import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663552147983/C6GwVHfwqojSL9ReUxxhxg/building-clouds-logo_7c9efe95.png";

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "Services", href: "#services" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);

      // Update active section
      const sections = navLinks.map((l) => l.href.replace("#", ""));
      for (const section of sections.reverse()) {
        const el = document.getElementById(section);
        if (el && window.scrollY >= el.offsetTop - 120) {
          setActive(section);
          break;
        }
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMobileOpen(false);
    const id = href.replace("#", "");
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#001F4D]/95 backdrop-blur-md shadow-lg shadow-[#001F4D]/20"
          : "bg-[#001F4D]"
      }`}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <a
            href="#home"
            onClick={(e) => { e.preventDefault(); handleNavClick("#home"); }}
            className="flex items-center gap-2 flex-shrink-0"
          >
            <img src={LOGO_URL} alt="Building Clouds" className="h-14 w-auto" />
          </a>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => { e.preventDefault(); handleNavClick(link.href); }}
                className={`nav-link text-sm font-medium tracking-wide transition-colors duration-200 ${
                  active === link.href.replace("#", "")
                    ? "text-[#FF6B35]"
                    : "text-white/80 hover:text-white"
                }`}
                style={{ fontFamily: "'Source Sans 3', sans-serif" }}
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden lg:flex items-center gap-4">
            <a
              href="#contact"
              onClick={(e) => { e.preventDefault(); handleNavClick("#contact"); }}
              className="px-5 py-2.5 bg-[#FF6B35] text-white text-sm font-semibold tracking-wide uppercase hover:bg-[#E55A24] transition-colors duration-200"
              style={{ fontFamily: "'Source Sans 3', sans-serif", letterSpacing: "0.08em" }}
            >
              Get Quote
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="lg:hidden text-white p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-[#001F4D] border-t border-white/10">
          <div className="container py-4 flex flex-col gap-1">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => { e.preventDefault(); handleNavClick(link.href); }}
                className={`py-3 px-2 text-sm font-medium border-b border-white/5 transition-colors duration-200 ${
                  active === link.href.replace("#", "")
                    ? "text-[#FF6B35]"
                    : "text-white/80"
                }`}
                style={{ fontFamily: "'Source Sans 3', sans-serif" }}
              >
                {link.label}
              </a>
            ))}
            <a
              href="#contact"
              onClick={(e) => { e.preventDefault(); handleNavClick("#contact"); }}
              className="mt-3 px-5 py-3 bg-[#FF6B35] text-white text-sm font-semibold text-center tracking-wide uppercase"
              style={{ fontFamily: "'Source Sans 3', sans-serif" }}
            >
              Get Quote
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
