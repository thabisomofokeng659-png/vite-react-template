/*
 * DESIGN: Precision Engineering Aesthetic
 * Stats: Full-width dark steel navy band breaking the light layout
 * Animated counters, gold accent numbers, JetBrains Mono for values
 */

import { useEffect, useRef, useState } from "react";

const stats = [
  { value: 5, suffix: "+", label: "Years in Business", description: "Young, dynamic team with proven expertise" },
  { value: 25, suffix: "+", label: "Projects Completed", description: "Across commercial & industrial sectors" },
  { value: 98, suffix: "+", label: "On-time delivery", description: "Maintanance, fabrications & site installtions" },
  { value: 98, suffix: "%", label: "Quality assurance", description: "Consistently meeting project deadlines" },
];

function useCounter(target: number, duration = 2000, active: boolean) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!active) return;
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [target, duration, active]);
  return count;
}

function StatItem({ value, suffix, label, description, active }: {
  value: number; suffix: string; label: string; description: string; active: boolean;
}) {
  const count = useCounter(value, 1800, active);
  return (
    <div className="flex flex-col items-center text-center px-6 py-8 border-r border-white/10 last:border-r-0">
      <div
        className="text-[#C9A84C] font-bold leading-none mb-2"
        style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.5rem, 5vw, 3.5rem)" }}
      >
        {count}{suffix}
      </div>
      <div
        className="text-white font-semibold mb-1 text-sm uppercase tracking-widest"
        style={{ fontFamily: "'Source Sans 3', sans-serif" }}
      >
        {label}
      </div>
      <div
        className="text-white/45 text-xs"
        style={{ fontFamily: "'Source Sans 3', sans-serif" }}
      >
        {description}
      </div>
    </div>
  );
}

export default function StatsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section className="bg-[#1C2B3A] relative overflow-hidden" ref={ref}>
      {/* Subtle texture overlay */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `repeating-linear-gradient(
            0deg,
            transparent,
            transparent 40px,
            rgba(201,168,76,0.3) 40px,
            rgba(201,168,76,0.3) 41px
          ), repeating-linear-gradient(
            90deg,
            transparent,
            transparent 40px,
            rgba(201,168,76,0.3) 40px,
            rgba(201,168,76,0.3) 41px
          )`,
        }}
      />

      <div className="container relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 divide-white/10">
          {stats.map((stat) => (
            <StatItem key={stat.label} {...stat} active={inView} />
          ))}
        </div>
      </div>
    </section>
  );
}
