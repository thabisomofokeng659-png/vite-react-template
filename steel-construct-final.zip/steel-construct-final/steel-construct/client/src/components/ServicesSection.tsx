/*
 * DESIGN: Building Clouds Branding
 * Services: Organized by category (Aluminum, Steel, Construction, Finishing)
 * Navy background, orange accents, service cards with icons
 */

import { useEffect, useRef, useState } from "react";
import {
  Square,
  DoorOpen,
  Home,
  Lock,
  Zap,
  Hammer,
  Wrench,
  Paintbrush,
} from "lucide-react";

const serviceCategories = [
  {
    title: "Aluminum Manufacture & Installation",
    color: "#FF6B35",
    services: [
      { icon: Square, name: "Windows", desc: "Custom aluminum window frames" },
      { icon: DoorOpen, name: "Doors", desc: "Aluminum entrance & sliding doors" },
      { icon: Home, name: "Garages", desc: "Aluminum garage doors & frames" },
      { icon: Lock, name: "Gates", desc: "Security gates & entrance gates" },
      { icon: Zap, name: "Guards", desc: "Security guards & railings" },
      { icon: Wrench, name: "Repair", desc: "Maintenance & repair services" },
    ],
  },
  {
    title: "Steel Works & Fittings",
    color: "#FF6B35",
    services: [
      { icon: Hammer, name: "Welding", desc: "Precision welding services" },
      { icon: Lock, name: "Window Burglar Bars", desc: "Steel security bars" },
      { icon: Lock, name: "Door Burglar Bars", desc: "Steel door protection" },
      { icon: Zap, name: "Palisades Fencing", desc: "Durable steel fencing" },
      { icon: DoorOpen, name: "Gates", desc: "Steel security gates" },
      { icon: Wrench, name: "Repair", desc: "Welding & repair services" },
    ],
  },
  {
    title: "Construction Works",
    color: "#FF6B35",
    services: [
      { icon: Hammer, name: "Civil Construction", desc: "Civil engineering projects" },
      { icon: Home, name: "Building Construction", desc: "Residential & commercial" },
      { icon: Zap, name: "Infrastructure", desc: "Large-scale infrastructure" },
      { icon: Wrench, name: "Earth Works", desc: "Excavation & site prep" },
      { icon: Hammer, name: "Structure Repairs", desc: "Structural repairs" },
      { icon: Paintbrush, name: "Renovations", desc: "Renovations & maintenance" },
    ],
  },
  {
    title: "Finishing & Installation",
    color: "#FF6B35",
    services: [
      { icon: Paintbrush, name: "Tiling", desc: "Professional tiling services" },
      { icon: Zap, name: "Electrical", desc: "Wiring & rewiring services" },
      { icon: Paintbrush, name: "Painting", desc: "Interior & exterior painting" },
      { icon: Home, name: "Interior Design", desc: "Design consultation" },
    ],
  },
];

export default function ServicesSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="services" className="py-24 lg:py-32 bg-[#F5F5F5]">
      <div className="container" ref={ref}>
        {/* Section Header */}
        <div
          className={`mb-16 text-center transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-8 h-px bg-[#FF6B35]" />
            <span
              className="text-[#FF6B35] uppercase tracking-[0.25em] text-xs font-semibold"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              What We Offer
            </span>
            <div className="w-8 h-px bg-[#FF6B35]" />
          </div>
          <h2
            className="text-[#001F4D] leading-tight"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
              fontWeight: 700,
            }}
          >
            Our{" "}
            <span className="text-[#FF6B35] italic">Services</span>
          </h2>
          <p
            className="text-[#666] mt-4 max-w-2xl mx-auto"
            style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "0.97rem" }}
          >
            Comprehensive aluminum fabrication, steel works, construction, and finishing services tailored to your project needs.
          </p>
        </div>

        {/* Service Categories */}
        <div className="space-y-12">
          {serviceCategories.map((category, categoryIdx) => (
            <div
              key={category.title}
              className={`transition-all duration-700 ${
                inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
              style={{ transitionDelay: `${categoryIdx * 100}ms` }}
            >
              {/* Category Title */}
              <div className="mb-6 pb-4 border-b-2 border-[#FF6B35]">
                <h3
                  className="text-[#001F4D] font-bold"
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "1.5rem",
                  }}
                >
                  {category.title}
                </h3>
              </div>

              {/* Services Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {category.services.map((service, serviceIdx) => {
                  const Icon = service.icon;
                  return (
                    <div
                      key={service.name}
                      className={`p-6 bg-white border-l-4 border-[#FF6B35] shadow-sm hover:shadow-md transition-all duration-300 group ${
                        inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
                      }`}
                      style={{ transitionDelay: `${categoryIdx * 100 + serviceIdx * 50}ms` }}
                    >
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-[#FF6B35]/10 flex items-center justify-center group-hover:bg-[#FF6B35]/20 transition-colors duration-300">
                          <Icon size={20} className="text-[#FF6B35]" />
                        </div>
                        <div>
                          <h4
                            className="text-[#001F4D] font-semibold mb-1"
                            style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                          >
                            {service.name}
                          </h4>
                          <p
                            className="text-[#666] text-sm"
                            style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                          >
                            {service.desc}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div
          className={`mt-16 text-center transition-all duration-700 ${
            inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ transitionDelay: "600ms" }}
        >
          <p
            className="text-[#666] mb-6"
            style={{ fontFamily: "'Source Sans 3', sans-serif" }}
          >
            Don't see what you're looking for? Contact us for custom solutions.
          </p>
          <a
            href="#contact"
            onClick={(e) => {
              e.preventDefault();
              document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
            }}
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-[#FF6B35] text-white font-semibold text-sm uppercase tracking-widest hover:bg-[#E55A24] transition-all duration-300"
            style={{ fontFamily: "'Source Sans 3', sans-serif" }}
          >
            Get a Quote
          </a>
        </div>
      </div>
    </section>
  );
}
