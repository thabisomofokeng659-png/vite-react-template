/*
 * DESIGN: Building Clouds Branding
 * About: Company overview, mission, vision, values, and profile download
 * Navy background with orange accents
 */

import { useEffect, useRef, useState } from "react";
import { Download, CheckCircle2, Zap, Shield, Award } from "lucide-react";

const PROFILE_PDF = "https://d2xsxph8kpxj0f.cloudfront.net/310519663552147983/C6GwVHfwqojSL9ReUxxhxg/Building-Clouds-Business-Profile_1220341a.pdf";

const values = [
  {
    icon: Award,
    title: "Excellence",
    description: "We pursue the highest standards in all our work",
  },
  {
    icon: Shield,
    title: "Safety",
    description: "We prioritize the wellbeing of our team and clients",
  },
  {
    icon: Zap,
    title: "Innovation",
    description: "We embrace new technologies and methods to improve outcomes",
  },
];

export default function AboutSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold: 0.15 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" className="py-24 lg:py-32 bg-[#001F4D]">
      <div className="container" ref={ref}>
        {/* Section Header */}
        <div
          className={`mb-16 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-px bg-[#FF6B35]" />
            <span
              className="text-[#FF6B35] uppercase tracking-[0.25em] text-xs font-semibold"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              About Us
            </span>
          </div>
          <h2
            className="text-white leading-tight max-w-2xl"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
              fontWeight: 700,
            }}
          >
            Building Clouds —{" "}
            <span className="text-[#FF6B35] italic">Excellence in Fabrication</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Left — Company Overview */}
          <div
            className={`transition-all duration-700 ${
              inView ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"
            }`}
          >
            <p
              className="text-white/80 leading-relaxed mb-6"
              style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "0.97rem" }}
            >
              Building Clouds (PTY) LTD is a fully registered and compliant South African company specializing in aluminum fabrication, steel works, and comprehensive construction services.
            </p>

            <p
              className="text-white/80 leading-relaxed mb-8"
              style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "0.97rem" }}
            >
              With a commitment to precision engineering, quality craftsmanship, and professional service delivery, we have established ourselves as a trusted partner for contractors, developers, and property owners across South Africa.
            </p>

            {/* Certifications */}
            <div className="mb-8">
              <h3
                className="text-[#FF6B35] text-xs uppercase tracking-[0.2em] mb-4 font-semibold"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                Certifications & Compliance
              </h3>
              <div className="space-y-2">
                {[
                  "CIDB Registered (10379064)",
                  "BBE Level 1 Certified",
                  "ISO Certified",
                  "SARS Compliant",
                  "POPIA Compliant",
                ].map((cert) => (
                  <div key={cert} className="flex items-center gap-2">
                    <CheckCircle2 size={14} className="text-[#FF6B35] flex-shrink-0" />
                    <span
                      className="text-white/70 text-sm"
                      style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                    >
                      {cert}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Download Profile Button */}
            <a
              href={PROFILE_PDF}
              download="Building-Clouds-Business-Profile.pdf"
              className="inline-flex items-center gap-2 px-6 py-3.5 bg-[#FF6B35] text-white font-semibold text-sm uppercase tracking-widest hover:bg-[#E55A24] transition-all duration-300"
              style={{ fontFamily: "'Source Sans 3', sans-serif" }}
            >
              <Download size={16} />
              Download Profile PDF
            </a>
          </div>

          {/* Right — Mission, Vision, Values */}
          <div
            className={`transition-all duration-700 ${
              inView ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"
            }`}
            style={{ transitionDelay: "200ms" }}
          >
            {/* Vision */}
            <div className="mb-8 p-6 border border-[#FF6B35]/30 bg-[#FF6B35]/5">
              <h3
                className="text-[#FF6B35] text-xs uppercase tracking-[0.2em] mb-3 font-semibold"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                Vision
              </h3>
              <p
                className="text-white/80 leading-relaxed"
                style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "0.95rem" }}
              >
                To be the leading provider of innovative aluminum, steel, and construction solutions in South Africa, recognized for our unwavering commitment to quality, safety, and customer satisfaction.
              </p>
            </div>

            {/* Mission */}
            <div className="mb-8 p-6 border border-[#FF6B35]/30 bg-[#FF6B35]/5">
              <h3
                className="text-[#FF6B35] text-xs uppercase tracking-[0.2em] mb-3 font-semibold"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                Mission
              </h3>
              <p
                className="text-white/80 leading-relaxed"
                style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "0.95rem" }}
              >
                To deliver exceptional fabrication and construction services that exceed client expectations through precision engineering, quality assurance, professional service, safety-first approach, and continuous innovation.
              </p>
            </div>

            {/* Core Values */}
            <div>
              <h3
                className="text-[#FF6B35] text-xs uppercase tracking-[0.2em] mb-4 font-semibold"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                Core Values
              </h3>
              <div className="space-y-3">
                {values.map((value) => {
                  const Icon = value.icon;
                  return (
                    <div key={value.title} className="flex items-start gap-3">
                      <Icon size={16} className="text-[#FF6B35] flex-shrink-0 mt-1" />
                      <div>
                        <div
                          className="text-white font-semibold text-sm"
                          style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                        >
                          {value.title}
                        </div>
                        <div
                          className="text-white/60 text-xs"
                          style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                        >
                          {value.description}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
