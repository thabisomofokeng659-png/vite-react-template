/*
 * DESIGN: Precision Engineering Aesthetic
 * Footer: Deep steel navy, gold logo accent, clean column layout
 */

export default function Footer() {
  const year = new Date().getFullYear();

  const handleNav = (href: string) => {
    const id = href.replace("#", "");
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-[#001F4D] text-white">
      <div className="container py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="mb-4">
              <div
                className="text-white font-bold leading-none mb-1"
                style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.1rem" }}
              >
                Building Clouds
              </div>
              <div
                className="text-[#FF6B35] leading-none tracking-[0.18em] uppercase text-xs"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                (PTY) LTD
              </div>
            </div>
            <p
              className="text-white/50 text-sm leading-relaxed"
              style={{ fontFamily: "'Source Sans 3', sans-serif" }}
            >
              Aluminum fabrication, steel works, and comprehensive construction services. CIDB Registered | BBE Level 1
            </p>
          </div>

          {/* Services */}
          <div>
            <h4
              className="text-[#FF6B35] text-xs uppercase tracking-[0.2em] mb-5"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              Services
            </h4>
            <ul className="space-y-2.5">
              {[
                "Aluminum Windows & Doors",
                "Steel Welding & Fabrication",
                "Construction Works",
                "Security Gates & Fencing",
                "Tiling & Painting",
                "Electrical Wiring",
              ].map((item) => (
                <li key={item}>
                  <a
                    href="#services"
                    onClick={(e) => { e.preventDefault(); handleNav("#services"); }}
                    className="text-white/55 text-sm hover:text-[#FF6B35] transition-colors duration-200"
                    style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4
              className="text-[#FF6B35] text-xs uppercase tracking-[0.2em] mb-5"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              Company
            </h4>
            <ul className="space-y-2.5">
              {[
                { label: "About Us", href: "#about" },
                { label: "Our Projects", href: "#projects" },
                { label: "Careers", href: "#contact" },
                { label: "News & Updates", href: "#contact" },
                { label: "Contact Us", href: "#contact" },
              ].map((item) => (
                <li key={item.label}>
                  <a
                    href={item.href}
                    onClick={(e) => { e.preventDefault(); handleNav(item.href); }}
                    className="text-white/55 text-sm hover:text-[#C9A84C] transition-colors duration-200"
                    style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4
              className="text-[#FF6B35] text-xs uppercase tracking-[0.2em] mb-5"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              Contact
            </h4>
            <div className="space-y-3">
              {[
                { label: "Phone", value: "0672977752" },
                { label: "Email", value: "info@buildingclouds.co.za" },
                { label: "Location", value: "Matatiele, Eastern Cape" },
              ].map((item) => (
                <div key={item.label}>
                  <div
                    className="text-white/30 text-xs uppercase tracking-widest"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}
                  >
                    {item.label}
                  </div>
                  <div
                    className="text-white/70 text-sm"
                    style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                  >
                    {item.value}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p
            className="text-white/30 text-xs"
            style={{ fontFamily: "'Source Sans 3', sans-serif" }}
          >
            © {year} Building Clouds (PTY) LTD. All rights reserved. | Reg: 2023/126083/07
          </p>
          <div className="flex gap-6">
            {["Privacy Policy", "Terms of Service", "Sitemap"].map((item) => (
              <a
                key={item}
                href="#"
                className="text-white/30 text-xs hover:text-[#FF6B35] transition-colors duration-200"
                style={{ fontFamily: "'Source Sans 3', sans-serif" }}
              >
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
