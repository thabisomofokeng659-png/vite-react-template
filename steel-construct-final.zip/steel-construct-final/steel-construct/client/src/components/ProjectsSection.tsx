/*
 * DESIGN: Precision Engineering Aesthetic
 * Projects: Asymmetric grid layout, dark overlay on hover, gold category tags
 * Warm off-white background, staggered entrance animations
 */

import { useEffect, useRef, useState } from "react";
import { ArrowUpRight } from "lucide-react";
import { trpc } from "@/lib/trpc";

const defaultProjects = [
  {
    id: "project-1",
    title: "Aluminum Gate & Door Fabrication - South Africa",
    category: "Steel",
    location: "South Africa",
    year: "2024",
    description: "Professional steel gate and door fabrication with precision welding and geometric design. Custom X-pattern security gates with burglar bars and sliding door systems.",
    image: "/manus-storage/steel-gate-project_01d6477c.jpg",
    size: "large",
  },
  {
    id: "project-2",
    title: "Aluminum Door with Burglar Bars",
    category: "Steel",
    location: "South Africa",
    year: "2024",
    description: "Custom Aluminum security door with decorative X-pattern burglar bars and reinforced frame. Combines security with elegant geometric design for residential and commercial properties.",
    image: "/manus-storage/steel-security-door_f2a38c37.jpg",
    size: "medium",
  },
  {
    id: "project-3",
    title: "Professional Welding & Fabrication Work",
    category: "Steel",
    location: "South Africa",
    year: "2024",
    description: "Expert welding and metal fabrication services. Our skilled team performs precision welding on steel gates, doors, and structural components with safety and quality assurance.",
    image: "/manus-storage/welding-project_464ee55a.jpg",
    size: "medium",
  },
  {
    id: "project-4",
    title: "Bridge Steel Structure",
    category: "Steel Fabrication",
    location: "Riyadh, KSA",
    year: "2022",
    description: "Fabrication and installation of 320 tonnes of structural steel for a pedestrian bridge.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663552147983/C6GwVHfwqojSL9ReUxxhxg/steel-fabrication-WVpK74YUtkCASBsivYhBAo.webp",
    size: "medium",
  },
];

const categoryColors: Record<string, string> = {
  "Construction": "#C9A84C",
  "Steel": "#7BA7BC",
  "Aluminum": "#A8C5A0",
  "Steel Fabrication": "#7BA7BC",
  "Aluminum Fabrication": "#A8C5A0",
};

export default function ProjectsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  const projectsQuery = trpc.projects.list.useQuery();
  const projects = projectsQuery.data && projectsQuery.data.length > 0 ? projectsQuery.data : defaultProjects;

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="projects" className="py-24 lg:py-32 bg-[#EFEFED]">
      <div className="container" ref={ref}>
        {/* Section Header */}
        <div
          className={`mb-16 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-px bg-[#C9A84C]" />
            <span
              className="text-[#C9A84C] uppercase tracking-[0.25em] text-xs"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              Our Work
            </span>
          </div>
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
            <h2
              className="text-[#1C2B3A] leading-tight max-w-lg"
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
                fontWeight: 700,
              }}
            >
              Featured{" "}
              <span className="text-[#C9A84C] italic">Projects</span>
            </h2>
            <p
              className="text-[#6B7280] leading-relaxed max-w-sm"
              style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "0.95rem" }}
            >
              A selection of landmark projects that demonstrate our capabilities across fabrication and construction.
            </p>
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Large featured project */}
          <div
            className={`lg:col-span-7 relative overflow-hidden group transition-all duration-700 ${
              inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
            style={{ transitionDelay: "0ms", minHeight: "420px" }}
          >
            <img
              src={(projects[0] as any).imageUrl || (projects[0] as any).image}
              alt={projects[0].title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              style={{ minHeight: "420px" }}
            />
            <div className="project-overlay absolute inset-0" />
            <div className="absolute bottom-0 left-0 right-0 p-8 z-10">
              <span
                className="inline-block px-3 py-1 text-xs uppercase tracking-widest mb-3"
                style={{
                  fontFamily: "'JetBrains Mono', monospace",
                  background: categoryColors[projects[0].category] || "#C9A84C",
                  color: "#1C2B3A",
                }}
              >
                {projects[0].category}
              </span>
              <h3
                className="text-white mb-2"
                style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.5rem", fontWeight: 600 }}
              >
                {projects[0].title}
              </h3>
              <p
                className="text-white/70 text-sm mb-4"
                style={{ fontFamily: "'Source Sans 3', sans-serif" }}
              >
                {projects[0].description}
              </p>
              <div className="flex items-center justify-between">
                <span
                  className="text-white/50 text-xs"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}
                >
                  {projects[0].location} · {projects[0].year}
                </span>
                <div className="w-8 h-8 border border-white/30 flex items-center justify-center group-hover:border-[#C9A84C] group-hover:bg-[#C9A84C] transition-all duration-300">
                  <ArrowUpRight size={14} className="text-white group-hover:text-[#1C2B3A] transition-colors duration-300" />
                </div>
              </div>
            </div>
          </div>

          {/* Right column — 3 smaller projects */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            {projects.slice(1).map((project, i) => (
              <div
                key={(project as any).id || project.title}
                className={`relative overflow-hidden group flex-1 transition-all duration-700 ${
                  inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                }`}
                style={{ transitionDelay: `${(i + 1) * 120}ms`, minHeight: "120px" }}
              >
                <img
                  src={(project as any).imageUrl || (project as any).image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  style={{ minHeight: "120px" }}
                />
                <div className="project-overlay absolute inset-0" />
                <div className="absolute bottom-0 left-0 right-0 p-5 z-10">
                  <span
                    className="inline-block px-2 py-0.5 text-xs uppercase tracking-widest mb-2"
                    style={{
                      fontFamily: "'JetBrains Mono', monospace",
                      background: categoryColors[project.category] || "#C9A84C",
                      color: "#1C2B3A",
                      fontSize: "0.6rem",
                    }}
                  >
                    {project.category}
                  </span>
                  <div className="flex items-center justify-between">
                    <h3
                      className="text-white text-sm font-semibold"
                      style={{ fontFamily: "'Playfair Display', serif" }}
                    >
                      {project.title}
                    </h3>
                    <ArrowUpRight size={14} className="text-white/60 group-hover:text-[#C9A84C] transition-colors duration-200 flex-shrink-0 ml-2" />
                  </div>
                  <span
                    className="text-white/45 text-xs"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}
                  >
                    {project.location} · {project.year}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* View All CTA */}
        <div
          className={`mt-10 flex justify-center transition-all duration-700 ${
            inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ transitionDelay: "600ms" }}
        >
          <a
            href="#contact"
            onClick={(e) => {
              e.preventDefault();
              document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
            }}
            className="inline-flex items-center gap-2 px-8 py-3.5 border-2 border-[#1C2B3A] text-[#1C2B3A] font-semibold text-sm uppercase tracking-widest hover:bg-[#1C2B3A] hover:text-white transition-all duration-300"
            style={{ fontFamily: "'Source Sans 3', sans-serif" }}
          >
            Discuss Your Project
            <ArrowUpRight size={16} />
          </a>
        </div>
      </div>
    </section>
  );
}
