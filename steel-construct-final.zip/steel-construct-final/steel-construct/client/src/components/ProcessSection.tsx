/*
 * DESIGN: Precision Engineering Aesthetic
 * Process: Horizontal numbered steps on warm off-white, gold connector lines
 * Clean, structured, engineering-precision feel
 */

import { useEffect, useRef, useState } from "react";
import { ClipboardList, Ruler, Factory, Truck, HardHat, BadgeCheck } from "lucide-react";

const steps = [
  {
    icon: ClipboardList,
    number: "01",
    title: "Consultation",
    description: "We meet with your team to understand project scope, specifications, timeline, and budget requirements.",
  },
  {
    icon: Ruler,
    number: "02",
    title: "Engineering & Design",
    description: "We create simple drawings and measurements so you know exactly what you're getting before we start cutting.",
  },
  {
    icon: Factory,
    number: "03",
    title: "Fabrication",
    description: "We fabricate your items in our workshop to the agreed design and spec.",
  },
  {
    icon: Truck,
    number: "04",
    title: "Delivery",
    description: "Coordinated logistics ensure fabricated components arrive on-site on schedule and in perfect condition.",
  },
  {
    icon: HardHat,
    number: "05",
    title: "Installation",
    description: "Our certified installation crews erect and fix all structural and architectural elements with precision.",
  },
  {
    icon: BadgeCheck,
    number: "06",
    title: "Handover",
    description: "Final inspection, quality certification, and full documentation package delivered to the client.",
  },
];

export default function ProcessSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section className="py-24 lg:py-32 bg-[#1C2B3A]">
      <div className="container" ref={ref}>
        {/* Section Header */}
        <div
          className={`mb-16 text-center transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-8 h-px bg-[#C9A84C]" />
            <span
              className="text-[#C9A84C] uppercase tracking-[0.25em] text-xs"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              How We Work
            </span>
            <div className="w-8 h-px bg-[#C9A84C]" />
          </div>
          <h2
            className="text-white leading-tight"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
              fontWeight: 700,
            }}
          >
            Our{" "}
            <span className="text-[#C9A84C] italic">Proven Process</span>
          </h2>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-0">
          {steps.map((step, i) => {
            const Icon = step.icon;
            const isLast = i === steps.length - 1;
            return (
              <div
                key={step.number}
                className={`relative p-8 border-b border-r border-white/10 transition-all duration-700 group hover:bg-white/5 ${
                  inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                } ${i % 3 === 2 ? "lg:border-r-0" : ""} ${i >= steps.length - (steps.length % 3 || 3) ? "sm:border-b-0" : ""}`}
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                {/* Large faint number */}
                <div
                  className="absolute top-4 right-6 text-white/[0.04] font-bold leading-none select-none pointer-events-none"
                  style={{ fontFamily: "'Playfair Display', serif", fontSize: "5rem" }}
                >
                  {step.number}
                </div>

                {/* Icon */}
                <div className="w-12 h-12 border border-[#C9A84C]/30 flex items-center justify-center mb-5 group-hover:border-[#C9A84C] transition-colors duration-300">
                  <Icon size={20} className="text-[#C9A84C]" />
                </div>

                {/* Step number label */}
                <div
                  className="text-[#C9A84C] text-xs uppercase tracking-[0.2em] mb-2"
                  style={{ fontFamily: "'JetBrains Mono', monospace" }}
                >
                  Step {step.number}
                </div>

                <h3
                  className="text-white mb-3"
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "1.15rem",
                    fontWeight: 600,
                  }}
                >
                  {step.title}
                </h3>
                <p
                  className="text-white/55 text-sm leading-relaxed"
                  style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                >
                  {step.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
