/*
 * DESIGN: Precision Engineering Aesthetic
 * Hero: Full-bleed dark overlay on construction image, asymmetric left-anchored text
 * Gold vertical rule, staggered fade-up animations, diagonal clip-path bottom divider
 */

import { useEffect, useRef, useState } from "react";
import { ArrowRight, ChevronDown } from "lucide-react";

const HERO_IMAGE =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663552147983/C6GwVHfwqojSL9ReUxxhxg/hero-steel-construction-oUu46EG2jPNdvbcjRqLshT.webp";

export default function HeroSection() {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const scrollToServices = () => {
    document.getElementById("services")?.scrollIntoView({ behavior: "smooth" });
  };

  const handleScroll = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="home"
      ref={ref}
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{ paddingTop: "80px" }}
    >
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src={HERO_IMAGE}
          alt="Steel construction at golden hour"
          className="w-full h-full object-cover object-center"
        />
        {/* Layered overlays for depth */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#001F4D]/90 via-[#001F4D]/70 to-[#001F4D]/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#001F4D]/60 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 container py-24 lg:py-32">
        <div className="max-w-3xl">
          {/* Section label */}
          <div
            className={`flex items-center gap-3 mb-6 transition-all duration-700 ${
              visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
            }`}
            style={{ transitionDelay: "0ms" }}
          >
            <div className="w-8 h-px bg-[#FF6B35]" />
            <span
              className="text-[#FF6B35] uppercase tracking-[0.25em] text-xs font-medium"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              5+ Years · Licensed & Certified
            </span>
          </div>

          {/* Main Headline */}
          <h1
            className={`text-white leading-[1.1] mb-6 transition-all duration-700 ${
              visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2.5rem, 6vw, 4.5rem)",
              fontWeight: 700,
              transitionDelay: "120ms",
            }}
          >
            Aluminum, Steel &<br />
            <span className="text-[#FF6B35] italic">Construction</span>
          </h1>

          {/* Sub-headline */}
          <p
            className={`text-white/75 text-lg leading-relaxed mb-10 max-w-xl transition-all duration-700 ${
              visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
            style={{
              fontFamily: "'Source Sans 3', sans-serif",
              transitionDelay: "240ms",
            }}
          >
            Building Clouds specializes in premium aluminum fabrication, steel works, and comprehensive construction services. From windows and doors to civil infrastructure, we deliver excellence with precision and professionalism.
          </p>

          {/* CTA Buttons */}
          <div
            className={`flex flex-wrap gap-4 transition-all duration-700 ${
              visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
            style={{ transitionDelay: "360ms" }}
          >
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#FF6B35] text-white font-semibold text-sm uppercase tracking-widest hover:bg-[#E55A24] transition-all duration-200 group"
              style={{ fontFamily: "'Source Sans 3', sans-serif" }}
            >
              Request a Quote
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform duration-200" />
            </a>
            <a
              href="#services"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById("services")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="inline-flex items-center gap-2 px-7 py-3.5 border border-white/40 text-white font-semibold text-sm uppercase tracking-widest hover:border-[#FF6B35] hover:text-[#FF6B35] transition-all duration-200"
              style={{ fontFamily: "'Source Sans 3', sans-serif" }}
            >
              View Services
            </a>
          </div>

          {/* Stats row */}
          <div
            className={`flex flex-wrap gap-8 mt-16 pt-8 border-t border-white/15 transition-all duration-700 ${
              visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
            style={{ transitionDelay: "480ms" }}
          >
            {[
              { value: "5+", label: "Years Experience" },
              { value: "500+", label: "Projects Completed" },
              { value: "100%", label: "Client Satisfaction" },
            ].map((stat) => (
              <div key={stat.label} className="flex flex-col">
                <span
                  className="text-[#FF6B35] font-bold leading-none"
                  style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.75rem" }}
                >
                  {stat.value}
                </span>
                <span
                  className="text-white/55 text-xs uppercase tracking-widest mt-1"
                  style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                >
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <button
        onClick={scrollToServices}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 text-white/50 hover:text-[#C9A84C] transition-colors duration-200"
        aria-label="Scroll down"
      >
        <span
          className="text-xs uppercase tracking-[0.2em]"
          style={{ fontFamily: "'JetBrains Mono', monospace" }}
        >
          Scroll
        </span>
        <ChevronDown size={18} className="animate-bounce" />
      </button>
      <div
        className="absolute bottom-0 left-0 right-0 z-10 h-16 bg-[#F5F5F5]"
        style={{ clipPath: "polygon(0 100%, 100% 0, 100% 100%)" }}
      />
    </section>
  );
}
