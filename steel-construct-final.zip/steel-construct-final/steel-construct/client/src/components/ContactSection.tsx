/*
 * DESIGN: Building Clouds Branding
 * Contact: Navy background, orange accents, clean form layout
 * Left: contact details; Right: quote request form
 */

import { useEffect, useRef, useState } from "react";
import { Phone, Mail, MapPin, Clock, Send, MessageCircle, Facebook, Music, Smartphone } from "lucide-react";

const contactDetails = [
  {
    icon: Phone,
    label: "Phone",
    value: "0672977752",
    sub: "Mon–Fri, 8:00 AM – 5:00 PM",
  },
  {
    icon: Mail,
    label: "Email",
    value: "info@buildingclouds.co.za",
    sub: "We respond within 24 hours",
  },
  {
    icon: MapPin,
    label: "Address",
    value: "Matatiele, Eastern Cape",
    sub: "South Africa | CIDB: 10379064",
  },
  {
    icon: Clock,
    label: "Working Hours",
    value: "Mon – Fri: 8:00 AM – 5:00 PM",
    sub: "Emergency: Available upon request",
  },
];

export default function ContactSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold: 0.2 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-24 lg:py-32 bg-[#001F4D] relative overflow-hidden">
      {/* Background grid texture */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: "url('data:image/svg+xml,%3Csvg width=\"60\" height=\"60\" viewBox=\"0 0 60 60\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cg fill=\"none\" fill-rule=\"evenodd\"%3E%3Cg fill=\"%23ffffff\" fill-opacity=\"0.1\"%3E%3Cpath d=\"M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')",
        }}
      />

      <div className="container relative z-10" ref={ref}>
        {/* Section Header */}
        <div
          className={`mb-14 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-px bg-[#FF6B35]" />
            <span
              className="text-[#FF6B35] uppercase tracking-[0.25em] text-xs"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              Get In Touch
            </span>
          </div>
          <h2
            className="text-white leading-tight max-w-lg"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
              fontWeight: 700,
            }}
          >
            Request a{" "}
            <span className="text-[#FF6B35] italic">Free Quote</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-16">
          {/* Left — Contact Details */}
          <div
            className={`lg:col-span-2 transition-all duration-700 ${
              inView ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"
            }`}
            style={{ transitionDelay: "100ms" }}
          >
            <p
              className="text-white/65 leading-relaxed mb-10"
              style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: "0.97rem" }}
            >
              Ready to start your next project? Our team is available to discuss your aluminum, steel, or construction requirements and provide a detailed, no-obligation quotation.
            </p>

            <div className="space-y-6">
              {contactDetails.map((detail) => {
                const Icon = detail.icon;
                return (
                  <div key={detail.label} className="flex items-start gap-4">
                    <div className="w-10 h-10 border border-[#FF6B35]/30 flex items-center justify-center flex-shrink-0">
                      <Icon size={16} className="text-[#FF6B35]" />
                    </div>
                    <div>
                      <div
                        className="text-[#FF6B35] text-xs uppercase tracking-widest mb-0.5"
                        style={{ fontFamily: "'JetBrains Mono', monospace" }}
                      >
                        {detail.label}
                      </div>
                      <div
                        className="text-white text-sm font-medium"
                        style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                      >
                        {detail.value}
                      </div>
                      <div
                        className="text-white/45 text-xs"
                        style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                      >
                        {detail.sub}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Divider */}
            <div className="mt-10 pt-8 border-t border-white/10">
              <p
                className="text-white/40 text-xs uppercase tracking-widest mb-3"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}
              >
                Connect With Us
              </p>
              <div className="flex gap-3">
                <a
                  href="https://wa.me/27672977752"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 border border-white/20 flex items-center justify-center text-white/50 hover:border-[#FF6B35] hover:text-[#FF6B35] transition-all duration-200 cursor-pointer"
                  title="WhatsApp"
                >
                  <MessageCircle size={18} />
                </a>
                <a
                  href="https://www.facebook.com/profile.php?id=100066849924681"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 border border-white/20 flex items-center justify-center text-white/50 hover:border-[#FF6B35] hover:text-[#FF6B35] transition-all duration-200 cursor-pointer"
                  title="Facebook"
                >
                  <Facebook size={18} />
                </a>
                <a
                  href="https://www.tiktok.com/@buildingclouds"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 border border-white/20 flex items-center justify-center text-white/50 hover:border-[#FF6B35] hover:text-[#FF6B35] transition-all duration-200 cursor-pointer"
                  title="TikTok"
                >
                  <Music size={18} />
                </a>
              </div>
            </div>
          </div>

          {/* Right — Contact Form */}
          <div
            className={`lg:col-span-3 transition-all duration-700 ${
              inView ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"
            }`}
            style={{ transitionDelay: "200ms" }}
          >
            {!submitted ? (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label
                      className="block text-white/60 text-xs uppercase tracking-widest mb-2"
                      style={{ fontFamily: "'JetBrains Mono', monospace" }}
                    >
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formState.name}
                      onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                      className="w-full bg-white/5 border border-white/15 text-white px-4 py-3 text-sm focus:outline-none focus:border-[#FF6B35] transition-colors duration-200 placeholder:text-white/25"
                      style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                      placeholder="Name & Surname"
                    />
                  </div>
                  <div>
                    <label
                      className="block text-white/60 text-xs uppercase tracking-widest mb-2"
                      style={{ fontFamily: "'JetBrains Mono', monospace" }}
                    >
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={formState.email}
                      onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                      className="w-full bg-white/5 border border-white/15 text-white px-4 py-3 text-sm focus:outline-none focus:border-[#FF6B35] transition-colors duration-200 placeholder:text-white/25"
                      style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                      placeholder="name@company.com"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label
                      className="block text-white/60 text-xs uppercase tracking-widest mb-2"
                      style={{ fontFamily: "'JetBrains Mono', monospace" }}
                    >
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      value={formState.phone}
                      onChange={(e) => setFormState({ ...formState, phone: e.target.value })}
                      className="w-full bg-white/5 border border-white/15 text-white px-4 py-3 text-sm focus:outline-none focus:border-[#FF6B35] transition-colors duration-200 placeholder:text-white/25"
                      style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                      placeholder="067 297 7752"
                    />
                  </div>
                  <div>
                    <label
                      className="block text-white/60 text-xs uppercase tracking-widest mb-2"
                      style={{ fontFamily: "'JetBrains Mono', monospace" }}
                    >
                      Service Required *
                    </label>
                    <select
                      required
                      value={formState.service}
                      onChange={(e) => setFormState({ ...formState, service: e.target.value })}
                      className="w-full bg-[#001F4D] border border-white/15 text-white px-4 py-3 text-sm focus:outline-none focus:border-[#FF6B35] transition-colors duration-200"
                      style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                    >
                      <option value="" disabled>Select a service</option>
                      <option value="aluminum">Aluminum Manufacture & Installation</option>
                      <option value="steel">Steel Works & Fittings</option>
                      <option value="construction">Construction Works</option>
                      <option value="finishing">Finishing & Installation</option>
                      <option value="custom">Custom Solution</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label
                    className="block text-white/60 text-xs uppercase tracking-widest mb-2"
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}
                  >
                    Project Description *
                  </label>
                  <textarea
                    required
                    rows={5}
                    value={formState.message}
                    onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                    className="w-full bg-white/5 border border-white/15 text-white px-4 py-3 text-sm focus:outline-none focus:border-[#FF6B35] transition-colors duration-200 placeholder:text-white/25 resize-none"
                    style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                    placeholder="Describe your project requirements, dimensions, materials, timeline..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 bg-[#FF6B35] text-white font-semibold text-sm uppercase tracking-widest hover:bg-[#E55A24] transition-colors duration-200"
                  style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                >
                  <Send size={15} />
                  Submit Request
                </button>
              </form>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 border border-[#FF6B35]/30 px-8">
                <div className="w-16 h-16 border-2 border-[#FF6B35] flex items-center justify-center mb-6">
                  <Send size={24} className="text-[#FF6B35]" />
                </div>
                <h3
                  className="text-white mb-3"
                  style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.5rem" }}
                >
                  Message Received
                </h3>
                <p
                  className="text-white/60 mb-6"
                  style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                >
                  Thank you for your inquiry. Our team will contact you within 24 hours to discuss your project in detail.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setFormState({ name: "", email: "", phone: "", service: "", message: "" });
                  }}
                  className="px-6 py-2 border border-[#FF6B35] text-[#FF6B35] text-sm uppercase tracking-widest hover:bg-[#FF6B35]/10 transition-colors duration-200"
                  style={{ fontFamily: "'Source Sans 3', sans-serif" }}
                >
                  Send Another
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
