import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { createProject, getProjects, getProjectById, updateProject, deleteProject } from "./db";
import { z } from "zod";
import { storagePut } from "./storage";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  projects: router({
    list: publicProcedure.query(async () => {
      return await getProjects();
    }),
    
    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await getProjectById(input.id);
    }),
    
    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        category: z.string().min(1),
        location: z.string().optional(),
        year: z.string().optional(),
        size: z.enum(["small", "medium", "large"]).default("medium"),
        imageFile: z.instanceof(Blob),
      }))
      .mutation(async ({ input }) => {
        const buffer = await input.imageFile.arrayBuffer();
        const fileName = `${Date.now()}-project-image.jpg`;
        const fileKey = `projects/${fileName}`;
        
        const { url } = await storagePut(fileKey, Buffer.from(buffer), input.imageFile.type);
        
        return await createProject({
          title: input.title,
          description: input.description,
          category: input.category,
          location: input.location,
          year: input.year,
          imageUrl: url,
          imageKey: fileKey,
          size: input.size,
        });
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        category: z.string().optional(),
        location: z.string().optional(),
        year: z.string().optional(),
        size: z.enum(["small", "medium", "large"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        return await updateProject(id, updates);
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await deleteProject(input.id);
      }),
  }),
});

export type AppRouter = typeof appRouter;
