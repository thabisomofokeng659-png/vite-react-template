import { describe, expect, it, afterEach } from "vitest";
import { createProject, getProjects, getProjectById, updateProject, deleteProject } from "./db";
import type { InsertProject } from "../drizzle/schema";

describe("Projects API", () => {
  // Store created project IDs for cleanup
  const createdIds: number[] = [];

  // Cleanup after each test
  afterEach(async () => {
    // Delete all created test projects
    for (const id of createdIds) {
      await deleteProject(id);
    }
    createdIds.length = 0;
  });

  const testProject: InsertProject = {
    title: "Test Project",
    description: "A test project for Building Clouds",
    category: "Aluminum",
    location: "Dubai, UAE",
    year: "2024",
    imageUrl: "https://example.com/test-image.jpg",
    imageKey: "projects/test-image.jpg",
    size: "medium",
  };

  it("should create a project", async () => {
    const project = await createProject(testProject);
    createdIds.push(project.id);
    expect(project).toBeDefined();
    expect(project.title).toBe("Test Project");
    expect(project.category).toBe("Aluminum");
    expect(project.imageUrl).toBe("https://example.com/test-image.jpg");
  });

  it("should retrieve all projects", async () => {
    const projects = await getProjects();
    expect(Array.isArray(projects)).toBe(true);
  });

  it("should retrieve a project by ID", async () => {
    const created = await createProject(testProject);
    createdIds.push(created.id);
    const retrieved = await getProjectById(created.id);
    expect(retrieved).toBeDefined();
    expect(retrieved?.title).toBe("Test Project");
  });

  it("should update a project", async () => {
    const created = await createProject(testProject);
    createdIds.push(created.id);
    const updated = await updateProject(created.id, {
      title: "Updated Project Title",
    });
    expect(updated?.title).toBe("Updated Project Title");
  });

  it("should delete a project", async () => {
    const created = await createProject(testProject);
    const deleted = await deleteProject(created.id);
    expect(deleted).toBe(true);
    const retrieved = await getProjectById(created.id);
    expect(retrieved).toBeUndefined();
  });

  it("should handle projects with different categories", async () => {
    const categories = ["Aluminum", "Steel", "Construction"];
    
    for (const category of categories) {
      const project = await createProject({
        ...testProject,
        title: `${category} Project`,
        category,
      });
      createdIds.push(project.id);
      expect(project.category).toBe(category);
    }
  });

  it("should handle projects with different grid sizes", async () => {
    const sizes = ["small", "medium", "large"] as const;
    
    for (const size of sizes) {
      const project = await createProject({
        ...testProject,
        title: `${size} Project`,
        size,
      });
      createdIds.push(project.id);
      expect(project.size).toBe(size);
    }
  });
});
